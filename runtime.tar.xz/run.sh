#!/bin/sh
# Knytt: a 32-bit Windows game, run with the trimmed Wine kept in this folder.
here=$(dirname "$(readlink -f "$0")")
# The prefix was made for a Windows user called "pi"; Wine uses that name for everyone.
export WINEPREFIX="$here/prefix" WINEUSERNAME=pi WINEDEBUG=-all
export WINEDLLOVERRIDES="mscoree,mshtml=;winemenubuilder.exe=d"
# Knytt unpacks its engine into the Windows temp folder on every start and leaves it
# behind when it is closed by force. Clear old copies unless the game is running.
pgrep -f 'mrt[0-9a-f]*\.tmp.stdrt\.exe' >/dev/null ||
  rm -rf "$here/prefix/drive_c/users/pi/AppData/Local/Temp/"mrt*.tmp
# Wake the X server first. If Wine is the first X client of an Xwayland that has
# not started yet, the game window never appears.
xdpyinfo >/dev/null 2>&1
cd "$here/game" && exec "$here/wine/bin/wine" Knytt.exe
